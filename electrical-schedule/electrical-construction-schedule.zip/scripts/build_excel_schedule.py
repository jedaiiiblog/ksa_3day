#!/usr/bin/env python
"""
전기 시공 공정표(엑셀 간트차트) 생성기

schedule_calculator.py 의 출력 JSON을 받아, 표(No/공종/내용/시작일/종료일/기간)와
일자별 간트 바가 포함된 xlsx 파일을 생성한다.

사용법:
    python build_excel_schedule.py schedule.json output.xlsx
"""
import json
import sys
from datetime import date, datetime, timedelta

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

HEADER_FILL = PatternFill("solid", fgColor="1F4E78")
HEADER_FONT = Font(color="FFFFFF", bold=True)
WEEKEND_FILL = PatternFill("solid", fgColor="F2F2F2")
HOLIDAY_FILL = PatternFill("solid", fgColor="FCE4D6")
CRIT_BAR_FILL = PatternFill("solid", fgColor="C00000")
BAR_FILL = PatternFill("solid", fgColor="4472C4")
THIN = Side(style="thin", color="D9D9D9")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

TABLE_COLS = ["No", "공종", "내용", "시작일", "종료일", "기간(일)"]
FIRST_DAY_COL = len(TABLE_COLS) + 1  # 1-indexed


def parse_date(s):
    return datetime.strptime(s, "%Y-%m-%d").date()


def build(schedule, out_path):
    start = parse_date(schedule["start_date"])
    end = parse_date(schedule["end_date"])
    holidays = set(schedule.get("holidays", []))
    weekday_map = {"Mon": 0, "Tue": 1, "Wed": 2, "Thu": 3, "Fri": 4, "Sat": 5, "Sun": 6}
    work_weekdays = {weekday_map[d] for d in schedule.get("work_days", ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"])}

    days = []
    d = start
    while d <= end:
        days.append(d)
        d += timedelta(days=1)

    wb = Workbook()
    ws = wb.active
    ws.title = "공사 스케줄"

    last_col = FIRST_DAY_COL + len(days) - 1

    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=last_col)
    ws.cell(row=1, column=1, value=f"{schedule.get('project_name') or '전기 시공'} 공정표").font = Font(bold=True, size=14)

    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=last_col)
    ws.cell(row=2, column=1,
            value=f"작성일: {date.today().isoformat()}  /  공사 기간: {schedule['start_date']} ~ {schedule['end_date']} ({schedule['total_calendar_days']}일)")

    header_row1 = 4  # 월 표시
    header_row2 = 5  # 일자/요일 + 표 헤더
    first_data_row = 6

    for i, name in enumerate(TABLE_COLS, start=1):
        c = ws.cell(row=header_row2, column=i, value=name)
        c.fill = HEADER_FILL
        c.font = HEADER_FONT
        c.alignment = Alignment(horizontal="center", vertical="center")
        c.border = BORDER
        ws.merge_cells(start_row=header_row1, start_column=i, end_row=header_row2, end_column=i)

    # 월별 병합 헤더 + 일자 헤더
    col = FIRST_DAY_COL
    month_start_col = {}
    for d in days:
        key = (d.year, d.month)
        month_start_col.setdefault(key, col)
        c = ws.cell(row=header_row2, column=col, value=d.day)
        c.font = Font(size=8)
        c.alignment = Alignment(horizontal="center")
        c.border = BORDER
        is_holiday = d.isoformat() in holidays
        is_weekend = d.weekday() not in work_weekdays
        if is_holiday:
            c.fill = HOLIDAY_FILL
        elif is_weekend:
            c.fill = WEEKEND_FILL
        ws.column_dimensions[get_column_letter(col)].width = 2.6
        col += 1

    for (yr, mo) in month_start_col:
        cols_for_month = [FIRST_DAY_COL + i2 for i2, d in enumerate(days) if (d.year, d.month) == (yr, mo)]
        c1, c2 = min(cols_for_month), max(cols_for_month)
        ws.merge_cells(start_row=header_row1, start_column=c1, end_row=header_row1, end_column=c2)
        mc = ws.cell(row=header_row1, column=c1, value=f"{mo}월")
        mc.font = Font(bold=True)
        mc.alignment = Alignment(horizontal="center")
        mc.fill = HEADER_FILL
        mc.font = HEADER_FONT

    tasks = schedule["tasks"]
    for idx, t in enumerate(tasks, start=1):
        row = first_data_row + idx - 1
        values = [idx, t.get("category") or t["name"], t.get("detail") or t["name"],
                  t["start_date"], t["end_date"], t["duration_days"]]
        for ci, v in enumerate(values, start=1):
            c = ws.cell(row=row, column=ci, value=v)
            c.border = BORDER
            c.alignment = Alignment(horizontal="center", vertical="center")

        t_start = parse_date(t["start_date"])
        t_end = parse_date(t["end_date"])
        fill = CRIT_BAR_FILL if t.get("critical") else BAR_FILL
        for i, d in enumerate(days):
            col = FIRST_DAY_COL + i
            cell = ws.cell(row=row, column=col)
            cell.border = BORDER
            if t_start <= d <= t_end:
                cell.fill = fill

    ws.column_dimensions["A"].width = 5
    ws.column_dimensions["B"].width = 18
    ws.column_dimensions["C"].width = 22
    ws.column_dimensions["D"].width = 12
    ws.column_dimensions["E"].width = 12
    ws.column_dimensions["F"].width = 8
    ws.freeze_panes = ws.cell(row=first_data_row, column=FIRST_DAY_COL)

    wb.save(out_path)
    print(f"엑셀 공정표 저장: {out_path}")


def main():
    if len(sys.argv) != 3:
        print("사용법: python build_excel_schedule.py <schedule.json> <output.xlsx>")
        sys.exit(1)
    with open(sys.argv[1], "r", encoding="utf-8") as f:
        schedule = json.load(f)
    build(schedule, sys.argv[2])


if __name__ == "__main__":
    main()
