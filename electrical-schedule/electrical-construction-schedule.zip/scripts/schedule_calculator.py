#!/usr/bin/env python
"""
전기 시공 WBS 공정 계산기 (Schedule Calculator)

입력 JSON(작업 목록 + 달력)을 받아 각 작업의 소요일수를 산출하고,
선후행 관계(predecessors)와 비작업일(휴일)을 반영해 시작일/종료일을 계산한다.

입력 JSON 스키마는 ../references/input_schema.md 참고.

사용법:
    python schedule_calculator.py input.json output.json
"""
import json
import sys
import math
from datetime import date, datetime, timedelta


def parse_date(s):
    return datetime.strptime(s, "%Y-%m-%d").date()


def daterange_is_workday(d, work_weekdays, holidays):
    # work_weekdays: set of Mon=0..Sun=6 that ARE working days
    if d.weekday() not in work_weekdays:
        return False
    if d.isoformat() in holidays:
        return False
    return True


def add_working_days(start_d, n_days, work_weekdays, holidays):
    """start_d 포함, n_days개의 작업일이 지난 마지막 날짜(종료일)를 반환.
    n_days=1 이면 start_d 당일이 첫 작업일이자 종료일이 될 수도 있음(단, start_d가 휴일이면 다음 작업일로 이동)."""
    d = start_d
    while not daterange_is_workday(d, work_weekdays, holidays):
        d += timedelta(days=1)
    remaining = n_days - 1
    while remaining > 0:
        d += timedelta(days=1)
        if daterange_is_workday(d, work_weekdays, holidays):
            remaining -= 1
    return d


def next_workday_on_or_after(d, work_weekdays, holidays):
    while not daterange_is_workday(d, work_weekdays, holidays):
        d += timedelta(days=1)
    return d


def previous_workday_on_or_before(d, work_weekdays, holidays):
    while not daterange_is_workday(d, work_weekdays, holidays):
        d -= timedelta(days=1)
    return d


def subtract_working_days(end_d, n_days, work_weekdays, holidays):
    """end_d 포함, n_days개의 작업일만큼 거슬러 올라간 첫 날짜(시작일)를 반환."""
    d = previous_workday_on_or_before(end_d, work_weekdays, holidays)
    remaining = n_days - 1
    while remaining > 0:
        d -= timedelta(days=1)
        if daterange_is_workday(d, work_weekdays, holidays):
            remaining -= 1
    return d


# 공종별 전용 입력(task_type)에 대한 기본 품셈값(예시, 검증 필요).
# references/productivity_reference.md 의 예시 범위 중간값을 사용했다.
SWITCHGEAR_INSTALL_DEFAULT_PRODUCTIVITY = 0.7  # 면/인/일 (수배전반 반입·거치)
DUCT_ROUTE_DEFAULT_PRODUCTIVITY = {
    "전선관": 25,       # m/인/일
    "케이블트레이": 18,  # m/인/일
}
FLOOR_PANEL_INSTALL_DEFAULT_PRODUCTIVITY = 1.5  # 면/인/일 (분전반 설치)
FLOOR_PANEL_WIRING_DEFAULT_PRODUCTIVITY = 100    # m/인/일 (관내 인입 전선 포설)


def _man_days_to_duration(man_days, crew_size, task_id):
    if crew_size <= 0:
        raise ValueError(f"작업 '{task_id}': crew_size는 0보다 커야 합니다.")
    return man_days / crew_size


def compute_duration_days(task):
    """task_type이 있으면 공종 전용 필드로, 없으면 quantity/productivity 또는
    duration_days 직접 지정값으로 소요일수를 산출한다."""
    if task.get("duration_days"):
        return int(math.ceil(task["duration_days"]))

    task_type = task.get("task_type")
    task_id = task.get("id")
    crew_size = task.get("crew_size", 1)

    if task_type == "수배전반설치":
        panel_count = task.get("panel_count")
        if panel_count is None:
            raise ValueError(f"작업 '{task_id}'(수배전반설치): panel_count(설치 면수)가 필요합니다.")
        productivity = task.get("productivity_override", SWITCHGEAR_INSTALL_DEFAULT_PRODUCTIVITY)
        man_days = panel_count / productivity
        duration = _man_days_to_duration(man_days, crew_size, task_id)
        return max(1, int(math.ceil(duration)))

    if task_type == "간선배관":
        length_m = task.get("length_m")
        if length_m is None:
            raise ValueError(f"작업 '{task_id}'(간선배관): length_m(배관 총 길이)이 필요합니다.")
        route_type = task.get("route_type", "전선관")
        default_productivity = DUCT_ROUTE_DEFAULT_PRODUCTIVITY.get(route_type, 20)
        productivity = task.get("productivity_override", default_productivity)
        man_days = length_m / productivity
        duration = _man_days_to_duration(man_days, crew_size, task_id)
        return max(1, int(math.ceil(duration)))

    if task_type == "층별분전반":
        panel_count = task.get("panel_count")
        wiring_length_m = task.get("wiring_length_m")
        if panel_count is None or wiring_length_m is None:
            raise ValueError(
                f"작업 '{task_id}'(층별분전반): panel_count(설치 면수)와 "
                "wiring_length_m(주전원으로부터 배선 거리 합계)가 필요합니다."
            )
        install_productivity = task.get("install_productivity_override", FLOOR_PANEL_INSTALL_DEFAULT_PRODUCTIVITY)
        wiring_productivity = task.get("wiring_productivity_override", FLOOR_PANEL_WIRING_DEFAULT_PRODUCTIVITY)
        install_man_days = panel_count / install_productivity
        wiring_man_days = wiring_length_m / wiring_productivity
        install_duration = _man_days_to_duration(install_man_days, crew_size, task_id)
        wiring_duration = _man_days_to_duration(wiring_man_days, crew_size, task_id)
        # 같은 인력이 설치 후 배선을 순차 진행한다고 가정(순차 합산).
        return max(1, int(math.ceil(install_duration + wiring_duration)))

    quantity = task.get("quantity")
    productivity = task.get("productivity")  # 1인 1일 표준 작업량 (물량/인공)

    if quantity is None or productivity is None:
        raise ValueError(
            f"작업 '{task_id}': duration_days, task_type 전용 필드, 또는 (quantity + productivity) 중 "
            "하나가 필요합니다."
        )
    if productivity <= 0:
        raise ValueError(f"작업 '{task_id}': productivity는 0보다 커야 합니다.")

    man_days = quantity / productivity
    duration = _man_days_to_duration(man_days, crew_size, task_id)
    return max(1, int(math.ceil(duration)))


def topological_order(tasks_by_id):
    visited = {}
    order = []

    def visit(tid, stack):
        if visited.get(tid) == "done":
            return
        if visited.get(tid) == "visiting":
            raise ValueError(f"순환 참조(circular dependency) 발견: {' -> '.join(stack + [tid])}")
        visited[tid] = "visiting"
        for pred in tasks_by_id[tid].get("predecessors", []):
            if pred not in tasks_by_id:
                raise ValueError(f"작업 '{tid}'의 선행작업 '{pred}'을(를) 찾을 수 없습니다.")
            visit(pred, stack + [tid])
        visited[tid] = "done"
        order.append(tid)

    for tid in tasks_by_id:
        visit(tid, [])
    return order


def calculate_schedule(data):
    project_start = parse_date(data["start_date"])
    work_weekday_names = data.get("work_days", ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"])
    weekday_map = {"Mon": 0, "Tue": 1, "Wed": 2, "Thu": 3, "Fri": 4, "Sat": 5, "Sun": 6}
    work_weekdays = {weekday_map[d] for d in work_weekday_names}
    holidays = set(data.get("holidays", []))

    tasks = data["tasks"]
    tasks_by_id = {t["id"]: t for t in tasks}
    order = topological_order(tasks_by_id)

    results = {}
    for tid in order:
        task = tasks_by_id[tid]
        duration = compute_duration_days(task)

        preds = task.get("predecessors", [])
        if not preds:
            earliest_start = project_start
        else:
            earliest_start = project_start
            for pred_id in preds:
                pred_result = results[pred_id]
                lag = task.get("lag_days", {}).get(pred_id, 0) if isinstance(task.get("lag_days"), dict) else task.get("lag_days", 0)
                candidate = pred_result["end_date"] + timedelta(days=1 + lag)
                if candidate > earliest_start:
                    earliest_start = candidate

        start_d = next_workday_on_or_after(earliest_start, work_weekdays, holidays)
        end_d = add_working_days(start_d, duration, work_weekdays, holidays)

        results[tid] = {
            "id": tid,
            "name": task.get("name", tid),
            "category": task.get("category", ""),
            "detail": task.get("detail", ""),
            "task_type": task.get("task_type"),
            "quantity": task.get("quantity"),
            "unit": task.get("unit"),
            "productivity": task.get("productivity"),
            "crew_size": task.get("crew_size"),
            "panel_count": task.get("panel_count"),
            "length_m": task.get("length_m"),
            "wiring_length_m": task.get("wiring_length_m"),
            "duration_days": duration,
            "predecessors": preds,
            "start_date": start_d,
            "end_date": end_d,
        }

    project_end = max(r["end_date"] for r in results.values())
    total_calendar_days = (project_end - project_start).days + 1

    # 임계경로(critical path): 후행작업 맵을 만들어 역방향으로 최만종료일(late finish)을 계산하고,
    # slack(late_finish - end_date)이 0인 작업만 critical로 표시한다.
    successors = {tid: [] for tid in tasks_by_id}
    for tid, r in results.items():
        for pred_id in r["predecessors"]:
            lag = r.get("lag_days", 0) if not isinstance(tasks_by_id[tid].get("lag_days"), dict) else tasks_by_id[tid]["lag_days"].get(pred_id, 0)
            successors[pred_id].append((tid, lag))

    late_finish = {}
    for tid in reversed(order):
        r = results[tid]
        succ_list = successors[tid]
        if not succ_list:
            late_finish[tid] = project_end
        else:
            candidates = []
            for succ_id, lag in succ_list:
                succ_duration = results[succ_id]["duration_days"]
                succ_late_start = subtract_working_days(late_finish[succ_id], succ_duration, work_weekdays, holidays)
                candidate = succ_late_start - timedelta(days=1 + lag)
                candidate = previous_workday_on_or_before(candidate, work_weekdays, holidays)
                candidates.append(candidate)
            late_finish[tid] = min(candidates)

    ordered_results = [results[tid] for tid in order]
    for r in ordered_results:
        r["critical"] = late_finish[r["id"]] == r["end_date"]
        r["start_date"] = r["start_date"].isoformat()
        r["end_date"] = r["end_date"].isoformat()

    return {
        "project_name": data.get("project_name", ""),
        "start_date": project_start.isoformat(),
        "end_date": project_end.isoformat(),
        "total_calendar_days": total_calendar_days,
        "work_days": work_weekday_names,
        "holidays": sorted(holidays),
        "tasks": ordered_results,
    }


def main():
    if len(sys.argv) != 3:
        print("사용법: python schedule_calculator.py <input.json> <output.json>")
        sys.exit(1)

    with open(sys.argv[1], "r", encoding="utf-8") as f:
        data = json.load(f)

    result = calculate_schedule(data)

    with open(sys.argv[2], "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"프로젝트: {result['project_name']}")
    print(f"전체 공사기간: {result['start_date']} ~ {result['end_date']} ({result['total_calendar_days']}일)")
    print(f"작업 수: {len(result['tasks'])}건")
    print(f"결과 저장: {sys.argv[2]}")


if __name__ == "__main__":
    main()
