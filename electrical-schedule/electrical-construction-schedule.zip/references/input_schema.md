# 입력 JSON 스키마 (schedule_calculator.py)

```json
{
  "project_name": "OO빌딩 전기설비공사",
  "start_date": "2026-10-05",
  "work_days": ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
  "holidays": ["2026-10-09", "2026-11-01"],
  "tasks": [
    {
      "id": "A1",
      "category": "배관공사",
      "name": "전선관 배관",
      "detail": "3층 사무실 전선관 배관",
      "quantity": 500,
      "unit": "m",
      "productivity": 60,
      "crew_size": 2,
      "predecessors": []
    },
    {
      "id": "A2",
      "category": "배선공사",
      "name": "전선 포설",
      "detail": "3층 사무실 전선 포설",
      "duration_days": 4,
      "predecessors": ["A1"],
      "lag_days": 0
    }
  ]
}
```

## 필드 설명

| 필드 | 필수 | 설명 |
|---|---|---|
| `project_name` | 아니오 | 공정표 제목에 사용 |
| `start_date` | 예 | 공사 착공일 (YYYY-MM-DD) |
| `work_days` | 아니오 | 작업 가능 요일. 기본값은 월~토 (일요일 휴무) |
| `holidays` | 아니오 | 공휴일·현장 휴무일 목록 (YYYY-MM-DD). 우천 예비일 등 알려진 비작업일도 미리 포함 가능 |
| `tasks[].id` | 예 | 작업 고유 ID (선후행 관계 참조용) |
| `tasks[].category` | 아니오 | 공종 대분류 (예: 배관, 배선, 기기설치, 결선, 시험) |
| `tasks[].name` / `detail` | 아니오 | 작업명 / 세부 내용 (공정표 표시용) |
| `tasks[].quantity` + `productivity` | quantity 방식 시 필수 | 물량과 1인 1일 표준 작업량(품셈). `references/productivity_reference.md` 참고 |
| `tasks[].crew_size` | 아니오 (기본 1) | 투입 인원수. `소요일수 = ceil(물량/품셈/인원)` |
| `tasks[].duration_days` | 직접 지정 시 필수 | 품셈 계산 없이 소요일수를 바로 지정하고 싶을 때 사용. 지정 시 다른 모든 산출 방식보다 우선함 |
| `tasks[].task_type` | 아니오 | `"수배전반설치"` / `"간선배관"` / `"층별분전반"` 중 하나를 지정하면 아래 "공종별 전용 필드"로 소요일수를 계산. 지정하지 않으면 quantity+productivity 방식 사용 |
| `tasks[].predecessors` | 아니오 | 선행 작업 id 목록. 모든 선행 작업이 끝난 다음 날부터 시작 |
| `tasks[].lag_days` | 아니오 | 선행 작업 종료 후 추가 대기일 (예: 콘크리트 양생, 자재 검수) |

## 공종별 전용 필드 (task_type)

`quantity`/`productivity`를 직접 계산하기보다, 아래 세 공종은 현장에서 바로 파악 가능한 값
(면수·거리·인원)을 넣으면 스크립트가 내부 품셈으로 환산한다. 사용자에게 이 필드들을 직접
질문해서 받는 방법은 `SKILL.md`의 "공종별 데이터 질문 체크리스트" 참고.

### `task_type: "수배전반설치"`

| 필드 | 필수 | 설명 |
|---|---|---|
| `panel_count` | 예 | 설치할 수배전반 면수 (EA) |
| `crew_size` | 아니오(기본 1) | 투입 인원 |
| `productivity_override` | 아니오 | 1인 1일 설치 가능 면수. 미지정 시 예시값 0.7 면/인/일 사용 |

계산식: `소요일수 = ceil(panel_count / productivity / crew_size)`

### `task_type: "간선배관"`

| 필드 | 필수 | 설명 |
|---|---|---|
| `length_m` | 예 | 배관(전선관·트레이) 총 길이 (m). 주전원(수배전반)에서 각 분전반/부하까지의 배관 거리 합계 |
| `route_type` | 아니오(기본 "전선관") | `"전선관"`(기본 품셈 25 m/인/일) 또는 `"케이블트레이"`(기본 18 m/인/일) |
| `crew_size` | 아니오(기본 1) | 투입 인원 |
| `productivity_override` | 아니오 | 품셈을 직접 지정하고 싶을 때 |

계산식: `소요일수 = ceil(length_m / productivity / crew_size)`

### `task_type: "층별분전반"`

| 필드 | 필수 | 설명 |
|---|---|---|
| `panel_count` | 예 | 설치할 분전반 면수 (보통 층수와 동일) |
| `wiring_length_m` | 예 | 주전원(간선)으로부터 각 분전반까지의 배선 거리 합계 (m) |
| `crew_size` | 아니오(기본 1) | 투입 인원 |
| `install_productivity_override` | 아니오 | 분전반 설치 품셈. 미지정 시 예시값 1.5 면/인/일 |
| `wiring_productivity_override` | 아니오 | 배선 포설 품셈. 미지정 시 예시값 100 m/인/일 |

계산식: `소요일수 = ceil(panel_count/install_productivity/crew_size + wiring_length_m/wiring_productivity/crew_size)`
(동일 인력이 설치 후 배선을 순차 진행한다고 가정하고, 두 작업 인공을 합산한 뒤 올림)

## 출력 (schedule.json)

각 작업에 `start_date`, `end_date`, `duration_days`, `critical`(임계경로 여부)이 채워져 반환된다.
이 결과를 `build_excel_schedule.py`에 넘기면 엑셀 간트차트가 만들어진다.
